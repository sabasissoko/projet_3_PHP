<?php
 
//die
require_once("model/inscription.model.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="publique/style.css">
</head>
<body>
    <div class="menu">
        <ul>
            <li> <a href="all.php?vue=1">AUTEUR</a> </li>
            <li> <a href="all.php?vue=2">OUVRAGE</a> </li>
            <li> <a href="all.php?vue=3">EXEMPLAIRE</a> </li>
            <li> <a href="all.php?vue=4">ADHERENT</a> </li>
            <li> <a href="all.php?vue=5">DEMANDE DE PRET</a> </li>
            <li> <a href="all.php?vue=6">PRETS</a></li>
        </ul>
    </div>
<?php
if (isset($_GET["vue"])){
    //$view=$_Get["view"];
    extract($_GET);// egal au precedent
    if($vue==1){
        require_once("vue/auteur.html.php");
    }elseif ($vue==2){
        require_once("vue/ouvrage.html.php");
    }elseif ($vue==3){
        require_once("vue/exemplaire.html.php");
    }elseif ($vue==4){
        require_once("vue/adherent.html.php");
    }elseif ($vue==5){
        require_once("vue/demande_pret.html.php");
    }
    elseif ($vue==6){
        require_once("vue/pret.html.php");
    }
}   
else{
    require_once("vue/auteur.html.php");
}
?>
</body>
</html>