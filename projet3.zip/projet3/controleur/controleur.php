<?php
require_once("model/inscription.model.php");
if(isset($_GET['vue'])){
    if(!(isset($_SESSION['user']))){
        header('location: index.php ');
    }
    extract($_GET);
    if($vue==1){
        $auteurs=find_auteur();
        $data['auteurs']=$auteurs;
        render_view('auteur',$data);
        }
    elseif ($vue==2){
        $ouvrages=find_ouvrage();
        $data['ouvrages']=$ouvrages;
        render_view('ouvrage',$data);
    }elseif ($vue==3){
        $exemplaires=find_exemplaire();
        $data['exemplaires']=$exemplaires;
        render_view('exemplaire',$data);
    }elseif ($vue==4){
        $adherents=find_adherent();
        $data['adherents']=$adherents;
        render_view('adherent',$data);
    }elseif ($vue==5){
        if($filtre==0){
            $demande_prets=find_demande_pret();
        }elseif($filtre==1){
            $demande_prets=find_demande_by_statut($niv);
        }
        $data['demande_prets']=$demande_prets;
        render_view('demande_pret',$data);
    }elseif ($vue==6){
        $prets=find_pret();
        $data['prets']=$prets;
        render_view('pret',$data);
    }elseif($vue==7){
        session_destroy();
        unset($_SESSION['user']);
        render_view('connexion',[],"base.connexion");
    } } 
else{
    render_view('connexion',[],"base.connexion");
}
if(isset($_POST['btnsave'])){
    extract($_POST);
    switch ($btnsave) {
        case 'recherche-demande':
            header("location: index.php?vue=5&filtre=1&niv=$niveau");
            break;
        case 'connexion':
                $users=find_all_user_by_login_and_password($_POST["login"],$_POST["password"]);
                if($users==null){
                    header('location:index.php');

                }else{
                    $_SESSION['user']=$users;
                    header('location:index.php?vue=1');
                }
                break;
        
        default:
            # code...
            break;
    }
}

function render_view(string $vue, array $data=[],string $base="base"):void{
    ob_start();
        extract($data);
        require_once("vue/".$vue.".html.php");
    $contentview=ob_get_clean();
    require_once("vue/".$base.".html.php");
}
?>