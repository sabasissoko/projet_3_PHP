<?php

function find_ouvrage():array{
    $ouvrages=[
        ["code"=>"E2231D","titre"=>"les compte d'Amadou koumba","date_edit"=>"12/04/2012","rayon"=>"compte"],
        ["code"=>"E1131D","titre"=>"pere riche pere pauvre","date_edit"=>"19/02/2016","rayon"=>"philosophie"],
        ["code"=>"AZ331D","titre"=>"Harry Potter","date_edit"=>"1997","rayon"=>"Serie litteraire"],
    ];
    return $ouvrages;
}


function find_auteur():array{
    $auteurs=[
        ["nom"=>"diop","prenom"=>"birago","profession"=>"ecrivain"],
        ["nom"=>"kiosaki","prenom"=>"robert","profession"=>"entrepreneur"],
        ["nom"=>"Rowling","prenom"=>"J.K","profession"=>"secretaire"],
    ];
    return $auteurs;
}


function find_exemplaire():array{
    $exemplaires=[
        ["code_ouvrage"=>"E2231D","code"=>"A224R","date_enrg"=>"02/04/2014"],
        ["code_ouvrage"=>"E1131D","code"=>"A55Y","date_enrg"=>"10/09/2020"],
    ];
    return $exemplaires;
}


function find_adherent():array{
    $adherents=[
        ["id"=>1,"nom"=>"sy","prenom"=>"boubacar","date_naiss"=>"02/04/1999","sexe"=>"M"],
        ["id"=>2,"nom"=>"diarra","prenom"=>"fatima","date_naiss"=>"18/05/2007","sexe"=>"F"],
        ["id"=>3,"nom"=>"coulibaly","prenom"=>"salimata","date_naiss"=>"08/12/1998","sexe"=>"F"],
        ["id"=>4,"nom"=>"keita","prenom"=>"hawa","date_naiss"=>"22/09/2004","sexe"=>"F"],
        ["id"=>5,"nom"=>"sarr","prenom"=>"abdou","date_naiss"=>"14/08/2001","sexe"=>"M"],
    ];
    return $adherents;
}


function find_demande_pret():array{
    $demande_prets=[
        ["id_adherent"=>1,"code_ouvrage"=>"E2231D","date_demande"=>"14/08/2017","statut"=>"valide"],
        ["id_adherent"=>2,"code_ouvrage"=>"E1131D","date_demande"=>"04/11/2020","statut"=>"annule"],
    ];
    return $demande_prets;
}


function find_pret():array{
    $prets=[
        ["date"=>"10/10/2014","date_retour_p"=>"25/10/2014","date_retour_r"=>"30/10/2014","code_exemplaire"=>"A224R","id_adherent"=>1],
        ["date"=>"02/12/2018","date_retour_p"=>"17/12/2018","date_retour_r"=>"05/01/2019","code_exemplaire"=>"A55Y","id_adherent"=>2],
    ];
    return $prets;
}

function find_ouvrage_by_rayon(string $rayon):array{
    $ouvragebyrayon=[];
    $ouvrages=find_ouvrage();
    foreach($ouvrages as $ouvrage){
        if($ouvrage["rayon"]==$rayon){
            $ouvragebyrayon[]=$ouvrage;
        }
    }
    return $ouvragebyrayon;
}


function find_adherent_by_id(int $id):array|null{
    $adherents=find_();
    foreach($adherents as $adh){
        if($adh["id"]==$id){
            return $adh;
        }
    }
    return null;
}

function find_all_demande():array{
    $demande_prets=find_demande_pret();
    $demande=[];
    foreach($demande_prets as $dem){
        $adherents=find_adherent_by_id($dem["id_adherent"]);
        $ouvrages=find_ouvrage_by_rayon($dem["code_ouvrage"]);
        $demande[]=[
            "id"=>$adh["id_adherent"],
            "code_ouvrage"=>$ouvrage["code_ouvrage"],
            "date_demande"=>$dem["date_demande"],
            "statut"=>$dem["statut"]
        ];
    }
    return $demande;
}

function find_all_pret():array{
    $prets=find_pret();
    $prett=[];
    foreach($prets as $pt){
        $adherents=find_adherent_by_id($pt["id_adherent"]);
        $exemplaires=find_exemplaire($pt["code_exemplaire"]);
        $prett[]=[
            "date"=>$pt["date"],
            "date_retour_p"=>$pt["date_retour_p"],
            "date_retour_r"=>$pt["date_retour_r"],
            "id_adherent"=>$adh["id_adherent"],
            
            "code_exemplaire"=>$pt["code_exemplaire"]
        ];
    }
    return $prett;
}

function find_all_exemplaire():array{
    $exemplaires=find_exemplaire();
    $exemp=[];
    foreach($exemplaires as $exp){
        $ouvrages=find_ouvrage_by_rayon($exp["code_ouvrage"]);
        $exemp[]=[
            "code_ouvrage"=>$ouvrage["code_ouvrage"],
            "code"=>$exp["code"],
            "date_enrg"=>["date_enrg"],
        ];
    }
    return $exemp;
}
?>