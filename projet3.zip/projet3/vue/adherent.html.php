<?php
$adherents=find_adherent();
?>
<div class="container">
<div class="class">
    <table>
        <tr>
           <th >ID</th>
           <th>NOM</th>
           <th >PRENOM</th>
           <th>DATE DE NAISSANCE</th>
           <th>SEXE</th>
        </tr>
        <?php foreach($adherents as $adherent):?>
        <tr>
            <td><?php echo($adherent["id"]) ?></td>
            <td><?= $adherent["nom"] ?></td>  <!-- syntaxte abreger de la premiere-->
            <td><?= $adherent["prenom"] ?></td>
            <td><?= $adherent["date_naiss"] ?></td>
            <td><?= $adherent["sexe"] ?></td>
        </tr>
        <?php endforeach ?>
    </table>
</div>
</div>