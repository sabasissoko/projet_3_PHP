<?php
$auteurs=find_auteur();
?>
<div class="container">
<div class="class">
    <table>
        <tr>
           <th >NOM</th>
           <th>PRENOM</th>
           <th>PROFESSION</th>
           
        </tr>
        <?php foreach($auteurs as $value):?>
        <tr>
            <td><?php echo($value["nom"]) ?></td>
            <td><?= $value["prenom"] ?></td> 
            <td><?= $value["profession"] ?></td>
        </tr>
        <?php endforeach ?>
    </table>
</div>
</div>