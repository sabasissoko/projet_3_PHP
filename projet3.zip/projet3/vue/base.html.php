<?php
require_once("model/inscription.model.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="publique/style.css">
</head>
<body>
    <div class="menu">
        <ul>
            <li> <a href="index.php?vue=1">AUTEUR</a> </li>
            <li> <a href="index.php?vue=2">OUVRAGE</a> </li>
            <li> <a href="index.php?vue=3">EXEMPLAIRE</a> </li>
            <li> <a href="index.php?vue=4">ADHERENT</a> </li>
            <li> <a href="index.php?vue=5&filtre=0">DEMANDE DE PRET</a> </li>
            <li> <a href="index.php?vue=6">PRETS</a></li>
            <li> <a href="index.php?vue=7">DECONNEXION</a></li>
        </ul>  
        <div class="user-connect" style="display: flex">
            <h3>NOM :<?=$_SESSION['user']['nom']?></h3>
            <h3>PRENOM :<?=$_SESSION['user']['prenom']?></h3>
        </div>
    </div>
    <?php
       echo($contentview);
    ?>
</body>
</html>