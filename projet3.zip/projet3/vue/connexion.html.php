<div class="conteneur">
    <div class="form" style="height: 200px">
        <form action="index.php" method="post" style="display : flex; flex-direction: column;">
            <div class="form-control">
                <label for="">Login :</label>
                <input type="text" name="login"  id="">
            </div>
            <div class="form-control">
                <label for="">Password :</label>
                <input type="password" name="password" id="">
            </div>
            <div class="form-control">
                <button type="submit" name="btnsave" value="connexion">Connexion</button>
            </div>
        </form>
    </div>
</div>