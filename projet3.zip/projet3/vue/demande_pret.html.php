<?php

$demande_prets=find_demande_pret();
?>
<div class="container">
<div class="class">
    <table>
        <tr>
           <th>ID ADHERENT</th>
           <th >CODE OUVRAGE</th>
           <th>DATE DE DEMANDE</th>
           <th>STATUT</th>
        </tr>
        <?php foreach($demande_prets as $demm):?>
        <tr>
            <td><?php echo($demm["id_adherent"]) ?></td>
            <td><?= $demm["code_ouvrage"] ?></td>  <!-- syntaxte abreger de la premiere-->
            <td><?= $demm["date_demande"] ?></td>
            <td><?= $demm["statut"] ?></td>
        </tr>
        <?php endforeach ?>
    </table>
</div>
</div>