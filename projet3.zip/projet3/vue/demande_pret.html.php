
<div class="container">
<div class="form">
        <form action="index.php" method="post">
            <div class="form-control">
                <label for="">Statut</label>
                <select name="niveau" id="">
                    <option value="valide">valide</option>
                    <option value="annule">annule</option>
                </select>
            </div>
            <div class="form-control">
                <button type="submit" name="btnsave" value="recherche-demande">Recherche</button>
            </div>
        </form>
    </div>
<div class="class">
    <table>
        <tr>
           <th>ID ADHERENT</th>
           <th >CODE OUVRAGE</th>
           <th>DATE DE DEMANDE</th>
           <th>STATUT</th>
        </tr>
        <?php foreach($demande_prets as $demm):?>
        <tr>
            <td><?= ($demm["id_adherent"]) ?></td>
            <td><?= $demm["code_ouvrage"] ?></td> 
            <td><?= $demm["date_demande"] ?></td>
            <td><?= $demm["statut"] ?></td>
        </tr>
        <?php endforeach ?>
    </table>
</div>
</div>