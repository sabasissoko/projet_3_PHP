<?php
$exemplaires=find_exemplaire();
?>
<div class="container">
<div class="class">
    <table>
        <tr>
           <th >CODE OUVRAGE</th>
           <th>CODE</th>
           <th>DATE ENREGISTREMENT</th>
        </tr>
        <?php foreach($exemplaires as $e):?>
        <tr>
            <td><?php echo($e["code_ouvrage"]) ?></td>
            <td><?= $e["code"] ?></td>  <!-- syntaxte abreger de la premiere-->
            <td><?= $e["date_enrg"] ?></td>
        </tr>
        <?php endforeach ?>
    </table>
</div>
</div>