<?php
$exemplaires=find_exemplaire();
?>
<div class="container">
<div class="class">
    <table>
        <tr>
           <th >CODE OUVRAGE</th>
           <th>CODE</th>
           <th>DATE ENREGISTREMENT</th>
        </tr>
        <?php foreach($exemplaires as $exemplaire):?>
        <tr>
            <td><?php echo($exemplaire["code_ouvrage"]) ?></td>
            <td><?= $exemplaire["code"] ?></td>
            <td><?= $exemplaire["date_enrg"] ?></td>
        </tr>
        <?php endforeach ?>
    </table>
</div>
</div>