<?php

$ouvrages=find_ouvrage();
?>
<div class="container">
<div class="class">
    <table>
        <tr>
           <th >CODE</th>
           <th>TITRE</th>
           <th >DATE EDITION</th>
           <th>RAYON</th>
        </tr>
        <?php foreach($ouvrages as $ouv):?>
        <tr>
            <td><?php echo($ouv["code"]) ?></td>
            <td><?= $ouv["titre"] ?></td>  <!-- syntaxte abreger de la premiere-->
            <td><?= $ouv["date_edit"] ?></td>
            <td><?= $ouv["rayon"] ?></td>
        </tr>
        <?php endforeach ?>
    </table>
</div>
</div>
