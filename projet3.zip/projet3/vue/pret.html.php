<?php
$prets=find_pret();
?>
<div class="container">
<div class="class">
    <table>
        <tr>
           <th >DATE</th>
           <th>DATE_RETOUR_P</th>
           <th >DATE_RETOUR_R</th>
           <th>CODE_EXEMPLAIRE</th>
           <th>ADHERENT</th>
        </tr>
        <?php foreach($prets as $p):?>
        <tr>
            <td><?php echo($p["date"]) ?></td>
            <td><?= $p["date_retour_p"] ?></td>  <!-- syntaxte abreger de la premiere-->
            <td><?= $p["date_retour_r"] ?></td>
            <td><?= $p["code_exemplaire"] ?></td>
            <td><?= $p["id_adherent"] ?></td>
        </tr>
        <?php endforeach ?>
    </table>
</div>
</div>